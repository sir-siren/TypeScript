const btn = document.querySelector('button')!;

btn.addEventListener('click', () => {
  console.log('Clicked!');
});